<?php
/**
 * Dashboard Widget: Active Posts
 *
 * @package Presence_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the "Active Posts" dashboard widget with Heartbeat integration.
 *
 * Shows which posts people have open, grouped by post with
 * an avatar stack of editors.
 *
 * @since 0.1.1
 */
class WP_Presence_Widget_Active_Posts {

	/**
	 * Registers the dashboard widget.
	 *
	 * @since 0.1.1
	 */
	public static function register() {
		if ( ! wp_can_access_presence_room( wp_presence_admin_room() ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'presence_active_posts',
			__( 'Active Posts', 'presence-api' ),
			array( __CLASS__, 'render' ),
			null,
			null,
			'normal',
			'default'
		);

		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
	}

	/**
	 * Enqueues the widget's CSS.
	 *
	 * @since 0.1.1
	 *
	 * @param string $hook_suffix The current admin page.
	 */
	public static function enqueue_scripts( $hook_suffix ) {
		if ( 'index.php' !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'presence-active-posts-widget',
			WP_PRESENCE_PLUGIN_URL . 'assets/css/widget-active-posts.css',
			array(),
			WP_PRESENCE_VERSION
		);
	}

	/**
	 * Renders the dashboard widget.
	 *
	 * @since 0.1.1
	 */
	public static function render() {
		echo '<div id="presence-active-posts-list" aria-live="polite" tabindex="-1">';
		echo self::list_markup( self::build_active_posts_data() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped as it is built.
		echo '</div>';
	}

	/**
	 * Returns the widget's list, as drawn on load and sent with each Heartbeat.
	 *
	 * @since 0.11.0
	 *
	 * @param array $posts Return value of self::build_active_posts_data().
	 * @return string HTML markup.
	 */
	private static function list_markup( $posts ) {
		if ( empty( $posts ) ) {
			return '<p>' . esc_html__( 'All quiet.', 'presence-api' ) . '</p>';
		}

		$html = '<ul class="presence-active-posts-list" aria-label="' . esc_attr__( 'Posts people have open', 'presence-api' ) . '">';

		foreach ( $posts as $post_data ) {
			$any_active = false;
			foreach ( $post_data['editors'] as $editor ) {
				if ( 'active' === $editor['status'] ) {
					$any_active = true;
					break;
				}
			}
			// Only show status when it differs, since "Idle" is the signal.
			// Active is the default state; labeling it adds noise.
			$status_label = $any_active ? '' : __( 'Idle', 'presence-api' );

			$html .= '<li class="presence-active-post-item" data-post-id="' . (int) $post_data['post_id'] . '">';

			$html     .= '<span class="presence-editor-stack">';
			$stack_max = min( count( $post_data['editors'] ), 4 );
			foreach ( array_slice( $post_data['editors'], 0, $stack_max ) as $index => $editor ) {
				$z     = $stack_max - $index;
				$title = $editor['is_agent'] ? self::agent_label( $editor['display_name'] ) : $editor['display_name'];
				$html .= '<img src="' . esc_url( $editor['avatar_url'] ) . '" width="24" height="24" style="z-index:' . (int) $z . '" alt="' . esc_attr( $editor['display_name'] ) . '" title="' . esc_attr( $title ) . '" />';
			}
			$html .= '</span>';

			$html .= '<div class="presence-active-post-info">';
			$html .= '<div><span class="presence-editor-count">' . esc_html( $post_data['editor_label'] ) . '</span></div>';
			$html .= '<div><span class="presence-post-title"><a href="' . esc_url( $post_data['edit_url'] ) . '">' . esc_html( $post_data['post_title'] ) . '</a></span></div>';

			// Touch has no hover to show the avatars' titles, and the stack only shows four, so everyone is spelled out there.
			if ( count( $post_data['editors'] ) > 1 ) {
				$names = array();
				foreach ( $post_data['editors'] as $editor ) {
					$names[] = $editor['is_agent'] ? self::agent_label( $editor['display_name'] ) : $editor['display_name'];
				}
				$html .= '<div class="presence-editor-names" aria-hidden="true">' . esc_html( wp_sprintf( '%l', $names ) ) . '</div>';
			}
			$html .= '</div>';

			$html .= '<span class="presence-status-text">' . esc_html( $status_label ) . '</span>';
			$html .= '</li>';
		}

		return $html . '</ul>';
	}

	/**
	 * Suffixes a display name to mark it as an agent's, everywhere this widget
	 * names one in plain text rather than through wp_presence_render_agent_badge(),
	 * since every editor_label string is passed through esc_html(), which would
	 * strip that badge's markup.
	 *
	 * @since 0.9.0
	 *
	 * @param string $display_name The agent's display name.
	 * @return string The name, suffixed to mark it as an agent's.
	 */
	private static function agent_label( $display_name ) {
		/* translators: %s: Display name. */
		return sprintf( __( '%s (agent)', 'presence-api' ), $display_name );
	}

	/**
	 * Handles the heartbeat received event for active posts updates.
	 *
	 * @since 0.1.1
	 *
	 * @param array  $response  The Heartbeat response.
	 * @param array  $data      The $_POST data sent.
	 * @param string $screen_id The screen ID.
	 * @return array The Heartbeat response.
	 */
	public static function heartbeat_received( $response, $data, $screen_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by filter signature.
		if ( ! wp_presence_fragment_request( $data, 'active-posts' ) ) {
			return $response;
		}

		if ( ! wp_can_access_presence_room( wp_presence_admin_room() ) ) {
			return $response;
		}

		$response['presence-fragments']['active-posts'] = self::list_markup( self::build_active_posts_data() );

		return $response;
	}

	/**
	 * Builds active posts data grouped by post.
	 *
	 * Returns an array of posts, each with an 'editors' array containing
	 * the users who have that post open.
	 *
	 * @since 0.1.1
	 * @since 0.11.0 Adds the post type to each editor label and titles untitled posts "(no title)".
	 * @since 0.11.0 Labels the post's lock holder with core's "is currently editing".
	 *
	 * @return array Array of post data with grouped editors.
	 */
	private static function build_active_posts_data() {
		$entries         = wp_get_presence_by_room_prefix( 'postType/' );
		$by_post         = array();
		$now             = time();
		$current_user_id = get_current_user_id();

		cache_users( wp_list_pluck( $entries, 'user_id' ) );

		// Prime post caches to avoid N+1 queries from get_post() and the
		// capability check in the loop. Neither reads the term or meta cache,
		// so priming those is two queries spent on nothing.
		$post_ids = array();
		foreach ( $entries as $entry ) {
			$parsed = wp_presence_parse_room( $entry->room );
			if ( $parsed ) {
				$post_ids[] = $parsed['post_id'];
			}
		}
		if ( ! empty( $post_ids ) ) {
			_prime_post_caches( $post_ids, false, false );
		}

		foreach ( $entries as $entry ) {
			$user = get_userdata( $entry->user_id );

			if ( ! $user ) {
				continue;
			}

			/* Parse room format: postType/{type}:{id} */
			$parsed = wp_presence_parse_room( $entry->room );

			if ( ! $parsed ) {
				continue;
			}

			$post_id   = $parsed['post_id'];
			$post_type = $parsed['post_type'];

			if ( ! post_type_supports( $post_type, 'presence' ) ) {
				continue;
			}

			// Anyone who edits a post type can render the widget, so without
			// this a contributor would receive the title, edit link and editors
			// of every post being worked on. Same check the REST controller
			// applies to the room collection.
			if ( ! wp_can_access_presence_room( $entry->room, $current_user_id ) ) {
				continue;
			}

			$post = get_post( $post_id );

			if ( ! $post ) {
				continue;
			}

			$elapsed = $now - strtotime( $entry->date_gmt . ' +0000' );
			$status  = $elapsed > wp_presence_idle_threshold() ? 'idle' : 'active';

			if ( ! isset( $by_post[ $post_id ] ) ) {
				// A new post holds core's "Auto Draft" placeholder until its first save.
				$untitled = '' === $post->post_title || 'auto-draft' === $post->post_status;

				$by_post[ $post_id ] = array(
					'post_id'    => $post_id,
					'post_title' => $untitled ? __( '(no title)', 'presence-api' ) : $post->post_title,
					'post_type'  => $post_type,
					'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
					'editors'    => array(),
				);
			}

			$editor_id = (int) $entry->user_id;

			// A user can hold more than one entry in a room. Rows arrive newest
			// first, so the one already seen is the freshest.
			if ( isset( $by_post[ $post_id ]['editors'][ $editor_id ] ) ) {
				continue;
			}

			$by_post[ $post_id ]['editors'][ $editor_id ] = array(
				'user_id'      => $editor_id,
				'display_name' => $user->display_name,
				'avatar_url'   => get_avatar_url( $user->ID, array( 'size' => wp_presence_get_avatar_fetch_size( 24 ) ) ),
				'status'       => $status,
				'is_agent'     => wp_presence_is_agent_user( $editor_id ),
			);
		}

		// Sort by number of editors descending.
		usort(
			$by_post,
			function ( $a, $b ) {
				return count( $b['editors'] ) - count( $a['editors'] );
			}
		);

		wp_presence_prime_post_locks( wp_list_pluck( $by_post, 'post_id' ) );

		/** This filter is documented in wp-admin/includes/ajax-actions.php */
		$window = (int) apply_filters( 'wp_check_post_lock_window', 150 );

		// Keyed by user id above; hand back a list.
		foreach ( $by_post as $index => $post_data ) {
			$lock    = explode( ':', (string) get_post_meta( $post_data['post_id'], '_edit_lock', true ) );
			$holder  = isset( $lock[1] ) && (int) $lock[0] > time() - $window ? (int) $lock[1] : 0;
			$editors = $post_data['editors'];
			$parts   = array();

			// Only the lock holder can change the post, so only they get core's wording for a lock.
			if ( isset( $editors[ $holder ] ) ) {
				$holder_name = $editors[ $holder ]['is_agent'] ? self::agent_label( $editors[ $holder ]['display_name'] ) : $editors[ $holder ]['display_name'];
				/* translators: %s: User's display name. */
				$parts[] = sprintf( __( '%s is currently editing', 'presence-api' ), $holder_name );
				$editors = array( $holder => $editors[ $holder ] ) + $editors;
			}

			$others = count( $editors ) - count( $parts );

			if ( $parts && $others ) {
				/* translators: %d: Number of other people with the post open. */
				$parts[] = sprintf( _n( '%d other', '%d others', $others, 'presence-api' ), $others );
			} elseif ( 1 === $others ) {
				$only_editor = reset( $editors );
				$parts[]     = $only_editor['is_agent'] ? self::agent_label( $only_editor['display_name'] ) : $only_editor['display_name'];
			} elseif ( $others ) {
				/* translators: %d: Number of people with the post open. */
				$parts[] = sprintf( _n( '%d person', '%d people', $others, 'presence-api' ), $others );
			}

			$by_post[ $index ]['editors']      = array_values( $editors );
			$by_post[ $index ]['editor_label'] = sprintf(
				/* translators: 1: Who has the post open. 2: Singular post type name, such as Page. */
				__( '%1$s · %2$s', 'presence-api' ),
				implode( wp_get_list_item_separator(), $parts ),
				get_post_type_object( $post_data['post_type'] )->labels->singular_name
			);
		}

		return array_values( $by_post );
	}

	/**
	 * Adds the hooks for the Active Posts widget.
	 *
	 * @access private
	 *
	 * @since 0.18.0
	 */
	public static function register_hooks() {
		add_action( 'wp_dashboard_setup', array( 'WP_Presence_Widget_Active_Posts', 'register' ) );
		add_filter( 'heartbeat_received', array( 'WP_Presence_Widget_Active_Posts', 'heartbeat_received' ), 10, 3 );
		// Puts Active Posts first for anyone without a saved Dashboard layout.
		add_filter( 'get_user_option_meta-box-order_dashboard', 'wp_presence_default_widget_order' );
	}
}
