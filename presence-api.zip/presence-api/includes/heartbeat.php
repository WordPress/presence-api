<?php
/**
 * Heartbeat presence handlers.
 *
 * @package Presence_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds the state stored on a user's entry in a post room.
 *
 * Shared so the two writers of that entry cannot drift apart on its shape.
 *
 * @access private
 *
 * @param string $screen_id The screen ID.
 * @param bool   $locked    Whether this write carries a post lock refresh.
 * @return array The state to store.
 */
function wp_presence_editor_state( $screen_id, $locked ) {
	return array(
		'action' => 'editing',
		'screen' => $screen_id,
		'locked' => (bool) $locked,
	);
}

/**
 * Returns how many consecutive unchanged ticks trigger the idle Heartbeat backoff.
 *
 * @access private
 *
 * @since 0.1.24
 *
 * @return int Tick count. Default 5. 0 disables the backoff.
 */
function wp_presence_get_heartbeat_idle_ticks() {
	/**
	 * Filters the tick count.
	 *
	 * @since 0.1.24
	 *
	 * @param int $ticks Tick count. Default 5.
	 */
	return (int) apply_filters( 'wp_presence_heartbeat_idle_ticks', 5 );
}

/**
 * Returns the desired widened Heartbeat interval, in seconds, for idle rooms.
 *
 * The client clamps this below the presence TTL, so it backs off by less
 * than this (or not at all) on a screen whose normal interval is already
 * near that ceiling.
 *
 * @access private
 *
 * @since 0.1.24
 *
 * @return int Interval in seconds. Default 45.
 */
function wp_presence_get_heartbeat_idle_interval() {
	/**
	 * Filters the interval.
	 *
	 * @since 0.1.24
	 *
	 * @param int $interval Interval in seconds. Default 45.
	 */
	return (int) apply_filters( 'wp_presence_heartbeat_idle_interval', 45 );
}

/**
 * Enqueues heartbeat and the presence ping script on all admin pages.
 */
function wp_presence_enqueue_heartbeat_ping() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	// On the front-end, only enqueue if the admin bar is showing.
	if ( ! is_admin() && ! is_admin_bar_showing() ) {
		return;
	}

	wp_enqueue_script( 'heartbeat' );

	$user_id = get_current_user_id();

	// Every page where the ping is enqueued occupies the admin/online room.
	$entries = array(
		array(
			'room'      => wp_presence_admin_room(),
			'client_id' => 'user-' . $user_id,
		),
	);

	// Carry a title for any frontend URL so it shows up in the Who's Online
	// widget (non-singular views — archives, search, the front page, taxonomies,
	// 404s — are labeled too). is_singular() pages also carry the post id.
	$front_context = null;
	if ( ! is_admin() ) {
		if ( is_front_page() ) {
			$title = __( 'Home', 'presence-api' );
		} else {
			$strip_branding = static function ( $parts ) {
				unset( $parts['tagline'], $parts['site'] );
				return $parts;
			};
			add_filter( 'document_title_parts', $strip_branding );
			$title = wp_get_document_title();
			remove_filter( 'document_title_parts', $strip_branding );
		}

		$front_context = array( 'title' => $title );

		if ( is_singular() ) {
			$queried = get_queried_object();
			if ( $queried instanceof WP_Post ) {
				$front_context['post_id'] = $queried->ID;
			}
		}
	}

	// On the post-edit screen, also occupy the per-post room.
	$editor_post_id = 0;
	$editor_room    = '';
	if ( is_admin() && function_exists( 'get_current_screen' ) ) {
		$screen = get_current_screen();
		if ( $screen && 'post' === $screen->base ) {
			$post = get_post();
			if ( $post && post_type_supports( $post->post_type, 'presence' ) ) {
				$room = wp_presence_post_room( $post->ID );
				if ( $room ) {
					$editor_post_id = $post->ID;
					$editor_room    = $room;
					$entries[]      = array(
						'room'      => $room,
						'client_id' => 'editor-' . $user_id,
					);
				}
			}
		}
	}

	// Write presence server-side during this request so the new page closes the
	// gap between the old page's pagehide DELETE and the next heartbeat tick.
	$screen_id = is_admin() && function_exists( 'get_current_screen' ) && get_current_screen()
		? get_current_screen()->id
		: 'front';

	$admin_state = array( 'screen' => $screen_id );
	if ( $front_context ) {
		if ( ! empty( $front_context['title'] ) ) {
			$admin_state['title'] = $front_context['title'];
		}
		if ( ! empty( $front_context['post_id'] ) ) {
			$admin_state['post_id'] = $front_context['post_id'];
		}
	}
	wp_set_presence( wp_presence_admin_room(), 'user-' . $user_id, $admin_state, $user_id );

	$initial_collaborator_count = 0;
	if ( $editor_room ) {
		// No tick has carried a lock refresh yet. connectNow() on load makes
		// that a single request, not a visible state.
		wp_set_presence(
			$editor_room,
			'editor-' . $user_id,
			wp_presence_editor_state( $screen_id, false ),
			$user_id
		);

		// Reads the room back, so a reload or late join into an already 2+
		// room seeds the same count the next tick would report.
		$initial_collaborator_count = wp_presence_count_editors( wp_get_presence( $editor_room ) );
	}

	$config = array(
		'entries'                  => $entries,
		'frontContext'             => $front_context,
		'editorPostId'             => $editor_post_id,
		// Lets presence-ping.js fire `presence-api.watchingRoom` without
		// duplicating the postType/{type}:{id} grammar client-side.
		'editorRoom'               => $editor_room,
		'initialCollaboratorCount' => $initial_collaborator_count,
		'restUrl'                  => esc_url_raw( rest_url( 'wp-presence/v1/presence' ) ),
		'nonce'                    => wp_create_nonce( 'wp_rest' ),
		'idleTicks'                => wp_presence_get_heartbeat_idle_ticks(),
		'idleInterval'             => wp_presence_get_heartbeat_idle_interval(),
		'ttl'                      => wp_presence_get_timeout(),
		'ttlMargin'                => wp_presence_ttl_margin(),
	);

	wp_enqueue_script(
		'wp-presence-tab-coordinator',
		WP_PRESENCE_PLUGIN_URL . 'assets/js/tab-coordinator.js',
		array( 'jquery' ),
		WP_PRESENCE_VERSION,
		true
	);

	wp_enqueue_script(
		'wp-presence-ping',
		WP_PRESENCE_PLUGIN_URL . 'assets/js/presence-ping.js',
		array( 'jquery', 'heartbeat', 'wp-hooks', 'wp-presence-tab-coordinator' ),
		WP_PRESENCE_VERSION,
		true
	);

	wp_add_inline_script(
		'wp-presence-ping',
		sprintf( 'window.wpPresenceConfig = %s;', wp_json_encode( $config, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) ),
		'before'
	);
}

/**
 * Records the current user's presence in the admin/online room on every tick.
 *
 * This is the API's primary write path. It runs regardless of which dashboard
 * widgets are registered.
 *
 * @param array  $response  The Heartbeat response.
 * @param array  $data      The $_POST data sent.
 * @param string $screen_id The screen ID.
 * Nonce verification is handled by WordPress in wp_ajax_heartbeat().
 *
 * @return array The Heartbeat response.
 */
function wp_presence_admin_heartbeat_received( $response, $data, $screen_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by filter signature.
	if ( empty( $data['presence-ping'] ) ) {
		return $response;
	}

	if ( ! current_user_can( 'edit_posts' ) ) {
		return $response;
	}

	$user_id = get_current_user_id();
	$screen  = isset( $data['presence-ping']['screen'] ) ? sanitize_text_field( $data['presence-ping']['screen'] ) : '';

	// Enrich post-editing screens with the post status.
	$post_status = '';
	if ( in_array( $screen, array( 'post', 'edit-post', 'page' ), true ) ) {
		// The editor heartbeat includes the post ID in wp-refresh-post-lock.
		$post_id = 0;
		if ( ! empty( $data['wp-refresh-post-lock']['post_id'] ) ) {
			$post_id = absint( $data['wp-refresh-post-lock']['post_id'] );
		} elseif ( ! empty( $data['presence-editor-ping']['post_id'] ) ) {
			$post_id = absint( $data['presence-editor-ping']['post_id'] );
		}
		if ( $post_id ) {
			$post = get_post( $post_id );
			if ( $post && current_user_can( 'edit_post', $post_id ) && isset( get_post_stati()[ $post->post_status ] ) ) {
				$post_status = $post->post_status;
			}
		}
	}

	$state = array( 'screen' => $screen );
	if ( $post_status ) {
		$state['post_status'] = $post_status;
	}

	// Store the frontend page label whenever the ping is from the public site.
	// title becomes the row's screen label in Who's Online; post_id is recorded
	// when the ping carries one (singular views).
	if ( 'front' === $screen ) {
		if ( ! empty( $data['presence-ping']['title'] ) ) {
			$state['title'] = sanitize_text_field( $data['presence-ping']['title'] );
		}
		$post_id = (int) ( $data['presence-ping']['post_id'] ?? 0 );
		if ( $post_id > 0 ) {
			$front_post = get_post( $post_id );
			if ( $front_post ) {
				$state['post_id'] = $front_post->ID;
			}
		}
	}

	wp_set_presence( wp_presence_admin_room(), 'user-' . $user_id, $state, $user_id );

	return $response;
}

/**
 * Handles the editor presence heartbeat and creates a presence entry for the post being edited.
 *
 * Also carries the room's current editor count back as
 * `presence-heartbeat-collaborators`, so a client can decide whether to start
 * a real-time sync loop without polling for it separately.
 *
 * @param array  $response  The Heartbeat response.
 * @param array  $data      The $_POST data sent.
 * @param string $screen_id The screen ID.
 * @return array The Heartbeat response.
 */
function wp_presence_editor_heartbeat_received( $response, $data, $screen_id ) {
	if ( empty( $data['presence-editor-ping']['post_id'] ) ) {
		return $response;
	}

	$post_id = absint( $data['presence-editor-ping']['post_id'] );
	$user_id = get_current_user_id();

	if ( ! $user_id || ! current_user_can( 'edit_post', $post_id ) ) {
		return $response;
	}

	$room = wp_presence_post_room( $post_id );

	if ( ! $room ) {
		return $response;
	}

	// Read per tick: a tick carrying no refresh means the lock is no longer
	// being held open, which is what the separate row's expiry used to say.
	$locked = ! empty( $data['wp-refresh-post-lock']['post_id'] )
		&& absint( $data['wp-refresh-post-lock']['post_id'] ) === $post_id;

	$state = wp_presence_editor_state( $screen_id, $locked );

	/**
	 * Filters the editor presence state before it's saved.
	 *
	 * Allows plugins to enrich the state data with additional metadata
	 * (e.g., cursor position, selected blocks, collaboration status).
	 *
	 * @since 0.1.21
	 *
	 * @param array $state   The presence state data.
	 * @param int   $post_id The post ID being edited.
	 * @param int   $user_id The user ID.
	 */
	$state = apply_filters( 'wp_presence_editor_state', $state, $post_id, $user_id );

	// The editor count below needs the room anyway. Reading it first lets an
	// unchanged tick skip the write.
	$rows = wp_presence_set_presence_in_rows(
		wp_presence_room_rows( $room ),
		$room,
		'editor-' . $user_id,
		$state,
		$user_id
	);

	$response['presence-heartbeat-collaborators'] = wp_presence_check_collaboration_threshold( $room, $rows );

	return $response;
}

/**
 * The reserved client_id holding a room's last observed editor count.
 *
 * @since 0.6.0
 *
 * @access private
 * @return string The reserved client_id.
 */
function wp_presence_collaboration_state_client_id() {
	return WP_PRESENCE_RESERVED_PREFIX . 'collab';
}

/**
 * Reads a room's last observed editor count out of its rows.
 *
 * @since 0.6.0
 *
 * @access private
 * @param array $rows Rows as returned by wp_presence_room_rows().
 * @return object|null The state row, or null when the room has none.
 */
function wp_presence_collaboration_state_row( $rows ) {
	foreach ( $rows as $row ) {
		if ( wp_presence_collaboration_state_client_id() === $row->client_id ) {
			return $row;
		}
	}

	return null;
}

/**
 * Counts the editor entries in a set of presence entries.
 *
 * @since 0.6.0
 *
 * @param array $entries Presence entries, as returned by wp_get_presence().
 * @return int The number of editor entries.
 */
function wp_presence_count_editors( $entries ) {
	return count(
		array_filter(
			$entries,
			static function ( $entry ) {
				return str_starts_with( $entry->client_id, 'editor-' );
			}
		)
	);
}

/**
 * Checks if the collaboration threshold has been crossed and fires appropriate actions.
 *
 * Fires 'wp_presence_collaboration_started' when editor count goes from 1 to 2+.
 * Fires 'wp_presence_collaboration_ended' when editor count goes from 2+ to 1.
 *
 * @since 0.1.21
 * @since 0.4.0 Returns the current editor count instead of void.
 * @since 0.9.0 Added the `$rows` parameter.
 *
 * @param string     $room The presence room identifier.
 * @param array|null $rows Optional. The room's rows, as returned by
 *                         wp_presence_room_rows(), for a caller that has
 *                         already read them. Default null, which reads them.
 * @return int The number of editors currently present in the room.
 */
function wp_presence_check_collaboration_threshold( $room, $rows = null ) {
	if ( null === $rows ) {
		$rows = wp_presence_room_rows( $room );
	}

	$entries      = wp_presence_client_rows( $rows );
	$editor_count = wp_presence_count_editors( $entries );

	// Every tick is its own request, so this cannot be held in memory. The
	// state row came back with the entries above and ages out on the same TTL:
	// once they have gone there is no earlier count left to be the edge from.
	$stored     = wp_presence_collaboration_state_row( $rows );
	$prev_count = $stored && isset( $stored->data['count'] ) ? (int) $stored->data['count'] : 1;

	if ( 1 === $prev_count && $editor_count >= 2 ) {
		/**
		 * Fires when collaboration starts (1 to 2+ editors).
		 *
		 * @since 0.1.21
		 *
		 * @param string $room    The presence room identifier.
		 * @param array  $entries The current presence entries.
		 */
		do_action( 'wp_presence_collaboration_started', $room, $entries );
	} elseif ( $prev_count >= 2 && 1 === $editor_count ) {
		/**
		 * Fires when collaboration ends (2+ to 1 editor).
		 *
		 * @since 0.1.21
		 *
		 * @param string $room    The presence room identifier.
		 * @param array  $entries The current presence entries.
		 */
		do_action( 'wp_presence_collaboration_ended', $room, $entries );
	}

	// Kept alive as it ages, not only when the count moves: a steady pair that
	// let this lapse would read back as a fresh start and re-announce itself.
	// Below two there is nothing to hold, since absent already reads as 1.
	if ( $editor_count >= 2 ) {
		wp_presence_store_collaboration_state( $room, $editor_count, $stored );
	} elseif ( $stored ) {
		wp_remove_presence( $room, wp_presence_collaboration_state_client_id() );
	}

	return $editor_count;
}

/**
 * Writes a room's editor count to its state row.
 *
 * @since 0.6.0
 *
 * @access private
 * @param string      $room   The presence room identifier.
 * @param int         $count  The current editor count.
 * @param object|null $stored The room's existing state row, if any.
 */
function wp_presence_store_collaboration_state( $room, $count, $stored ) {
	$threshold = wp_presence_refresh_threshold();
	$unchanged = $stored && isset( $stored->data['count'] ) && (int) $stored->data['count'] === $count;
	$age       = $stored ? time() - (int) strtotime( $stored->date_gmt . ' UTC' ) : 0;

	// Same rule as wp_presence_refresh_cutoff(), decided from the row already read.
	if ( $unchanged && $threshold > 0 && $age <= $threshold ) {
		return;
	}

	wp_presence_write_row(
		$room,
		wp_presence_collaboration_state_client_id(),
		0,
		wp_json_encode( array( 'count' => $count ) ),
		gmdate( 'Y-m-d H:i:s' )
	);
}

/**
 * Adds the Heartbeat check to Site Health.
 *
 * @access private
 *
 * @since 0.7.1
 *
 * @param array $tests Site Health tests.
 * @return array The tests.
 */
function wp_presence_site_status_tests( $tests ) {
	if ( wp_presence_is_available() ) {
		$tests['direct']['presence_heartbeat'] = array(
			'label' => __( 'Heartbeat keeps presence current', 'presence-api' ),
			'test'  => 'wp_presence_site_health_heartbeat_test',
		);
	}

	return $tests;
}

/**
 * Tests whether Heartbeat refreshes presence rows before they expire.
 *
 * Only a page load writes presence without Heartbeat, so a user who stays on
 * one screen past the TTL drops out of Who's Online while still there.
 *
 * @access private
 *
 * @since 0.7.1
 *
 * @return array The Site Health result.
 */
function wp_presence_site_health_heartbeat_test() {
	$result = array(
		'label'       => __( 'Heartbeat keeps presence current', 'presence-api' ),
		'status'      => 'good',
		'badge'       => array(
			'label' => __( 'Presence', 'presence-api' ),
			'color' => 'blue',
		),
		'description' => '<p>' . __( 'Heartbeat refreshes each user&#8217;s presence while they stay on one screen.', 'presence-api' ) . '</p>',
		'actions'     => '',
		'test'        => 'presence_heartbeat',
	);

	$limit = wp_presence_get_timeout() - wp_presence_ttl_margin();

	if ( ! wp_script_is( 'heartbeat', 'registered' ) ) {
		/* translators: %d: Presence timeout in seconds. */
		$problem = sprintf( __( 'Heartbeat is turned off, so Who&#8217;s Online misses anyone who has not loaded a page in the last %d seconds.', 'presence-api' ), wp_presence_get_timeout() );
	} else {
		// Read what core already filtered for this page, so no callback runs twice.
		$settings = preg_match( '/var heartbeatSettings = (.*);$/m', (string) wp_scripts()->get_data( 'heartbeat', 'data' ), $matches ) ? json_decode( $matches[1], true ) : array();
		$interval = empty( $settings['interval'] ) ? 60 : (int) $settings['interval'];

		// Core ticks a background tab every two minutes, whatever the interval.
		if ( max( $interval, MINUTE_IN_SECONDS * 2 ) <= $limit ) {
			return $result;
		}

		/* translators: %d: Longest Heartbeat interval presence tolerates, in seconds. */
		$problem = sprintf( __( 'Heartbeat runs less often than every %d seconds, so Who&#8217;s Online drops people who stay on one screen.', 'presence-api' ), $limit );
	}

	$result['label']       = __( 'Heartbeat is not keeping presence current', 'presence-api' );
	$result['status']      = 'recommended';
	$result['description'] = '<p>' . $problem . '</p><p>' . __( 'A plugin that controls Heartbeat, or code removing its script, is the usual cause.', 'presence-api' ) . '</p>';

	return $result;
}
