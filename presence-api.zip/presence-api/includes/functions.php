<?php
/**
 * Presence API functions.
 *
 * Public API:
 *   wp_get_presence()
 *   wp_set_presence()
 *   wp_remove_presence()
 *   wp_presence_exchange()
 *   wp_presence_leave()
 *   wp_remove_user_presence()
 *   wp_can_access_presence_room()
 *   wp_presence_post_room()
 *   wp_presence_admin_room()
 *   wp_presence_recording_enabled()
 *   wp_presence_is_available()
 *
 * @package Presence_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



/**
 * Whether the current site has a presence table to query.
 *
 * Sites are provisioned at activation and at site creation, but a site on a
 * large network, or one added while the plugin was not network active, can
 * serve requests before either has happened. Presence is not essential to
 * rendering a page, so those requests return nothing instead of raising a
 * database error.
 *
 * The option is set by wp_maybe_create_presence_table() and is autoloaded, so
 * this costs nothing beyond a cache lookup. Any value counts, including one
 * from an older schema: the table is there, and the admin upgrade path will
 * bring it current.
 *
 * @access private
 * @return bool Whether presence storage is available on this site.
 */
function wp_presence_has_table() {
	return (bool) get_option( 'wp_presence_db_version' );
}

/**
 * Returns the date_gmt floor a read applies on top of a row's own expiry.
 *
 * A caller that named no window has no opinion about staleness, so the row's
 * expiry is the only bound and this floor matches every stored row.
 *
 * @access private
 *
 * @since 0.7.0
 *
 * @param int|null $timeout The caller's window in seconds, or null for none.
 * @return string A floor in `Y-m-d H:i:s`, UTC.
 */
function wp_presence_read_floor( $timeout ) {
	if ( null === $timeout ) {
		return '1000-01-01 00:00:00';
	}

	return gmdate( 'Y-m-d H:i:s', time() - wp_presence_get_timeout( $timeout ) );
}

/**
 * Gets all present clients in a room, filtered by TTL.
 *
 * Reserved rows are left out whatever the prefix, so `_` returns nothing.
 *
 * A `$timeout` given here is the window used, on every site. Omit it to take
 * the site's own TTL, which is what `wp_presence_default_ttl` filters.
 *
 * @since 0.7.0 Added the `$client_prefix` parameter.
 * @since 0.7.0 An explicit `$timeout` is no longer overridden by `wp_presence_default_ttl`.
 *
 * @param string $room          The room identifier.
 * @param int    $timeout       Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @param string $client_prefix Optional. Only return clients whose client_id starts with this.
 *                              Default empty.
 * @return array Array of presence entry objects.
 */
function wp_get_presence( $room, $timeout = null, $client_prefix = '' ) {
	return wp_presence_client_rows( wp_presence_room_rows( $room, $timeout, $client_prefix ) );
}

/**
 * Whether a client_id is the plugin's own bookkeeping rather than a client.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @param string $client_id The client identifier.
 * @return bool Whether the id is reserved.
 */
function wp_presence_is_reserved_client_id( $client_id ) {
	return str_starts_with( (string) $client_id, WP_PRESENCE_RESERVED_PREFIX );
}

/**
 * Returns the LIKE pattern matching every reserved client_id.
 *
 * For the queries that read rows by room in SQL rather than through
 * wp_get_presence(), which filters them out in PHP.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @return string An escaped LIKE pattern.
 */
function wp_presence_reserved_client_id_pattern() {
	global $wpdb;

	return $wpdb->esc_like( WP_PRESENCE_RESERVED_PREFIX ) . '%';
}

/**
 * Drops the reserved rows from a set of rows.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @param array $rows Rows as returned by wp_presence_room_rows().
 * @return array The rows that belong to clients.
 */
function wp_presence_client_rows( $rows ) {
	return array_values(
		array_filter(
			$rows,
			static function ( $row ) {
				return ! wp_presence_is_reserved_client_id( $row->client_id );
			}
		)
	);
}

/**
 * Gets every live row in a room, the reserved rows included.
 *
 * One query serves both the participants and the plugin's own state for the
 * room, so reading that state costs nothing on top of the read the caller
 * was already making.
 *
 * @access private
 *
 * @since 0.6.0
 * @since 0.7.0 Added the `$client_prefix` parameter.
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string $room          The room identifier.
 * @param int    $timeout       Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @param string $client_prefix Optional. Only return rows whose client_id starts with this.
 *                              Default empty.
 * @return array Array of presence row objects.
 */
function wp_presence_room_rows( $room, $timeout = null, $client_prefix = '' ) {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return array();
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );
	$stale  = wp_presence_read_floor( $timeout );

	$client_clause = '';
	$args          = array( $room, $cutoff, $stale );

	if ( '' !== (string) $client_prefix ) {
		$client_clause = ' AND client_id LIKE %s';
		// Escaped, since LIKE reads `_` and `%` as wildcards.
		$args[] = $wpdb->esc_like( (string) $client_prefix ) . '%';
	}

	// Presence data is ephemeral and changes on every heartbeat; caching would serve stale data.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$results = $wpdb->get_results(
		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT room, client_id, user_id, data, date_gmt FROM {$wpdb->presence} WHERE room = %s AND expires_gmt > %s AND date_gmt > %s{$client_clause} ORDER BY date_gmt DESC",
			...$args
		)
	);

	if ( ! $results ) {
		return array();
	}

	foreach ( $results as $row ) {
		$decoded   = json_decode( $row->data, true );
		$row->data = is_array( $decoded ) ? $decoded : array();
	}

	return $results;
}

/**
 * Returns the user IDs present in a set of entries, the current user included.
 *
 * The current user's own row is absent on screens that never ping and once it
 * ages past the TTL, so it is added by identity rather than by adding one,
 * which would double-count whenever the row is there.
 *
 * @access private
 *
 * @param array $entries Presence entries, as returned by wp_get_presence().
 * @return int[] Unique user IDs.
 */
function wp_presence_online_user_ids( $entries ) {
	$online_ids = array_map( 'intval', wp_list_pluck( wp_presence_with_current_user( $entries ), 'user_id' ) );

	return array_values( array_unique( $online_ids ) );
}

/**
 * Adds an entry for the current user to a set of entries when their row is absent.
 *
 * @access private
 *
 * @param array $entries Presence entries, as returned by wp_get_presence().
 * @return array Entries with the current user included.
 */
function wp_presence_with_current_user( $entries ) {
	$current_id = get_current_user_id();

	if ( ! $current_id ) {
		return $entries;
	}

	foreach ( $entries as $entry ) {
		if ( (int) $entry->user_id === $current_id ) {
			return $entries;
		}
	}

	$entries[] = (object) array(
		'user_id'  => $current_id,
		'date_gmt' => current_time( 'mysql', true ),
		'data'     => array(),
	);

	return $entries;
}

/**
 * Whether presence is recorded on this site.
 *
 * The controller-level switch, checked at the single write path. Nothing new is
 * stored while this is false and every surface empties within one
 * WP_PRESENCE_DEFAULT_TTL as the rows already there expire, so there is no
 * separate teardown to run.
 *
 * Recording is on by default. Presence is a negative signal, and the post lock
 * bridge is where its absence stops two people overwriting each other, so the
 * default is the safe one; a site that would rather not process it at all
 * switches it off here and says so in its privacy policy.
 *
 * The stored options are passed as the filters' defaults, so a filter always
 * has the last word over whatever the checkbox says.
 *
 * Aggregating those rows into the network-wide view is a separate switch. See
 * wp_presence_network_aggregation_enabled().
 *
 * @since 0.3.0
 *
 * @return bool Whether presence is recorded.
 */
function wp_presence_recording_enabled() {
	/**
	 * Filters whether presence is recorded on this site.
	 *
	 * @since 0.3.0
	 *
	 * @param bool $enabled Whether to record presence. Default is the
	 *                      wp_presence_recording option, true on a new install.
	 */
	$enabled = (bool) apply_filters( 'wp_presence_recording_enabled', (bool) get_option( 'wp_presence_recording', true ) );

	if ( ! $enabled || ! is_multisite() ) {
		return $enabled;
	}

	/**
	 * Filters whether presence is recorded anywhere on this network.
	 *
	 * Consulted only once the site-level filter has allowed recording, so
	 * either switch turning off wins and neither can turn the other back on.
	 *
	 * @since 0.3.0
	 *
	 * @param bool $enabled Whether to record presence. Default is the
	 *                      wp_presence_network_recording site option, true on a
	 *                      new install.
	 */
	return (bool) apply_filters( 'wp_presence_network_recording_enabled', (bool) get_site_option( 'wp_presence_network_recording', true ) );
}

/**
 * Whether presence can be read and written on this site.
 *
 * The check an integrator makes before relying on presence. On a site with
 * no table, or with recording switched off, wp_set_presence() returns false
 * and wp_get_presence() returns an empty array, which reads as an empty room
 * rather than an unavailable backend. Guard with function_exists() first to
 * cover the plugin not being loaded.
 *
 * @since 0.6.0
 *
 * @return bool Whether the table exists and presence is recorded.
 */
function wp_presence_is_available() {
	return wp_presence_has_table() && wp_presence_recording_enabled();
}

/**
 * Returns how long until the client is expected to send its next Heartbeat.
 *
 * @access private
 *
 * @since 0.4.0
 *
 * @return int Seconds.
 */
function wp_presence_next_tick_gap() {
	// Core's scheduleNextTick() overrides the interval to 120s whenever the
	// window is blurred, and never reflects that back into the interval it
	// reports in the same request, so the reported value understates the real
	// gap on an unfocused tab. That is the worst case, and the assumption to
	// make whenever the request does not say otherwise.
	$blurred = 120;

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by WordPress in wp_ajax_heartbeat() before any of this runs.
	if ( ! isset( $_POST['interval'], $_POST['has_focus'] ) || 'true' !== $_POST['has_focus'] ) {
		return $blurred;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- As above.
	$interval = absint( $_POST['interval'] );

	return $interval > 0 ? $interval : $blurred;
}

/**
 * Returns how stale a presence row is allowed to get while its client is still
 * pinging.
 *
 * A row's date_gmt is the only evidence a reader has that its client is still
 * there, so a write skipped to save a query is indistinguishable from a client
 * that left. This bounds how long that ambiguity lasts.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @return int Age in seconds.
 */
function wp_presence_max_staleness() {
	return 30;
}

/**
 * Returns the age past which a presence row means its client has gone quiet.
 *
 * A row this old cannot be explained by a skipped write followed by the widest
 * gap a pinging client leaves, so the client really has stopped. Anything
 * reading date_gmt to tell active from idle has to use this rather than a
 * figure of its own, or a client that is merely economising on writes reads as
 * one that walked away.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @return int Age in seconds.
 */
function wp_presence_idle_threshold() {
	return wp_presence_max_staleness() + wp_presence_get_heartbeat_idle_interval();
}

/**
 * Returns the age at which an unchanged presence row still has to be rewritten.
 *
 * Skipping a write leaves the row's existing date_gmt in place, so it is only
 * safe while the row will still be inside wp_get_presence()'s cutoff when the
 * next tick arrives. Deriving this from wp_presence_get_timeout() rather than
 * WP_PRESENCE_DEFAULT_TTL matters: a site filtering the TTL below the tick
 * interval would otherwise make its users blink offline.
 *
 * Staying inside the cutoff is not enough on its own, since a row can sit
 * unwritten well inside the TTL and still read as long gone, so
 * wp_presence_max_staleness() caps it as well.
 *
 * @access private
 *
 * @since 0.4.0
 *
 * @return int Age in seconds. 0 means never skip.
 */
function wp_presence_refresh_threshold() {
	$timeout = wp_presence_get_timeout();

	return max( 0, min( $timeout - wp_presence_ttl_margin() - wp_presence_next_tick_gap(), wp_presence_max_staleness() ) );
}

/**
 * Returns the slice of the TTL kept in reserve rather than spent on waiting.
 *
 * Both sides of the plugin push their timing as close to the TTL as they dare,
 * the server when it skips a write and the client when it widens its interval.
 * Either one landing late drops a present user out of the room, so they hold
 * back by the same amount, and presence-ping.js is passed this figure.
 *
 * @access private
 *
 * @since 0.6.0
 *
 * @return int Seconds.
 */
function wp_presence_ttl_margin() {
	return 15;
}

/**
 * Returns the Gravatar size to request for an avatar displayed at a given size.
 *
 * @access private
 *
 * @since 0.5.0
 *
 * @param int $display_size The avatar's displayed size in pixels.
 * @return int The size to request, for a sharp image on a 2x display.
 */
function wp_presence_get_avatar_fetch_size( $display_size ) {
	return (int) $display_size * 2;
}

/**
 * Returns the date_gmt below which an unchanged row still has to be refreshed.
 *
 * @access private
 *
 * @since 0.7.0
 *
 * @param string $room The room identifier.
 * @return string A 'Y-m-d H:i:s' GMT timestamp, or an empty string when the
 *                write must land whatever the stored row holds.
 */
function wp_presence_refresh_cutoff( $room ) {
	$threshold = wp_presence_refresh_threshold();

	if ( $threshold <= 0 ) {
		return '';
	}

	// The network summary push hangs off wp_presence_admin_room_changed, so an
	// admin-room write that is skipped also skips the push. Loaded on multisite
	// only, hence the guard.
	if ( wp_presence_admin_room() === $room
		&& function_exists( 'wp_presence_network_summary_push_is_due' )
		&& wp_presence_network_summary_push_is_due()
	) {
		return '';
	}

	return gmdate( 'Y-m-d H:i:s', time() - $threshold );
}

/**
 * Whether a string is a real calendar date in 'Y-m-d H:i:s' format.
 *
 * Same approach as wp_resolve_post_date(): a preg_match on the literal shape
 * plus wp_checkdate() to catch a well-formed but impossible date (2026-02-30).
 *
 * @access private
 *
 * @since 0.4.0
 *
 * @param string $date_gmt The timestamp to validate.
 * @return bool Whether the timestamp is well-formed and real.
 */
function wp_presence_is_valid_date_gmt( $date_gmt ) {
	if ( ! is_string( $date_gmt )
		|| ! preg_match( '/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/', $date_gmt, $matches )
	) {
		return false;
	}

	list( , $year, $month, $day, $hour, $minute, $second ) = $matches;

	if ( (int) $hour > 23 || (int) $minute > 59 || (int) $second > 59 ) {
		return false;
	}

	return wp_checkdate( (int) $month, (int) $day, (int) $year, $date_gmt );
}

/**
 * Upserts a client's presence state in a room.
 *
 * Uses INSERT ... ON DUPLICATE KEY UPDATE for atomic upserts
 * via the UNIQUE KEY (room, client_id).
 *
 * @since 0.4.0 Added the $date_gmt parameter.
 * @since 0.7.0 Added the $expires_in parameter.
 *
 * @param string      $room      The room identifier.
 * @param string      $client_id The client identifier.
 * @param array       $state     The presence state data.
 * @param int         $user_id   Optional. The user ID. Default 0.
 * @param string|null $date_gmt  Optional. The GMT timestamp to stamp the row
 *                                with, as 'Y-m-d H:i:s' (the same shape
 *                                `wp_get_presence()` returns as `date_gmt`).
 *                                For a caller relaying awareness on behalf of
 *                                other clients, so it can preserve their
 *                                timestamps instead of stamping every
 *                                relayed row with its own clock. A value in
 *                                the future is clamped to now, since
 *                                otherwise a caller could pin a row past the
 *                                TTL indefinitely. Must be a real calendar
 *                                date or the write is rejected. Default null
 *                                (now).
 * @param int|null    $expires_in Optional. Seconds from `$date_gmt` that the
 *                                row counts as present, for a caller that
 *                                knows when its clients leave and removes
 *                                their rows itself: the window is then the
 *                                backstop for a departure that never arrived,
 *                                rather than the interval it has to keep
 *                                re-stamping inside. Capped by the
 *                                `wp_presence_max_expires_in` filter, and a
 *                                value below one second is rejected. Default
 *                                null (the site TTL).
 * @return bool True on success, false on failure (including a malformed
 *              $date_gmt or an unusable $expires_in).
 */
function wp_set_presence( $room, $client_id, $state, $user_id = 0, $date_gmt = null, $expires_in = null ) {
	if ( ! wp_presence_recording_enabled() ) {
		return false;
	}

	if ( ! wp_presence_has_table() ) {
		return false;
	}

	if ( null !== $date_gmt && ! wp_presence_is_valid_date_gmt( $date_gmt ) ) {
		return false;
	}

	if ( null !== $expires_in && ( ! is_numeric( $expires_in ) || (int) $expires_in < 1 ) ) {
		return false;
	}

	$data_json = wp_json_encode( $state );
	$current   = gmdate( 'Y-m-d H:i:s' );
	$now       = null === $date_gmt ? $current : min( $date_gmt, $current );

	$expires_gmt = wp_presence_expiry_for( $now, $expires_in );

	/*
	 * An explicit timestamp is how a relay backdates a collaborator who has
	 * since left; skipping it here would leave them looking present. An
	 * explicit expiry is the same kind of deliberate write, and skipping one
	 * would drop the extension the caller asked for.
	 */
	$refresh_cutoff = null === $date_gmt && null === $expires_in ? wp_presence_refresh_cutoff( $room ) : '';

	return wp_presence_write_row( $room, $client_id, $user_id, $data_json, $now, $expires_gmt, $refresh_cutoff );
}

/**
 * Upserts a client's presence state into a room the caller has already read.
 *
 * For a caller that needs the room's rows anyway. The client's own row is
 * among them, so the rule the upsert applies in SQL (same data, stamped after
 * the refresh cutoff) can be applied here instead, and an unchanged tick costs
 * no write at all.
 *
 * @access private
 *
 * @since 0.9.0
 *
 * @param array  $rows      Rows for `$room`, as returned by wp_presence_room_rows()
 *                          with no client prefix.
 * @param string $room      The room identifier.
 * @param string $client_id The client identifier.
 * @param array  $state     The presence state data.
 * @param int    $user_id   Optional. The user ID. Default 0.
 * @return array The rows, with the client's own row as it now stands.
 */
function wp_presence_set_presence_in_rows( $rows, $room, $client_id, $state, $user_id = 0 ) {
	$own = null;

	foreach ( $rows as $index => $row ) {
		if ( $client_id === $row->client_id ) {
			$own = $index;
			break;
		}
	}

	$cutoff = wp_presence_refresh_cutoff( $room );

	if ( null !== $own
		&& '' !== $cutoff
		&& $rows[ $own ]->date_gmt >= $cutoff
		&& wp_json_encode( $rows[ $own ]->data ) === wp_json_encode( $state )
	) {
		return $rows;
	}

	if ( ! wp_set_presence( $room, $client_id, $state, $user_id ) ) {
		return $rows;
	}

	if ( null !== $own ) {
		unset( $rows[ $own ] );
	}

	// Newest first, the order wp_presence_room_rows() returns.
	array_unshift(
		$rows,
		(object) array(
			'room'      => $room,
			'client_id' => $client_id,
			'user_id'   => (string) $user_id,
			'data'      => $state,
			'date_gmt'  => gmdate( 'Y-m-d H:i:s' ),
		)
	);

	return array_values( $rows );
}

/**
 * The expiry stamped on a row, from the window its writer asked for.
 *
 * A writer that knows when its clients leave, such as one relaying a socket's
 * lifetime, asks for a long window and removes the row itself; the expiry is
 * then the backstop for a departure that never arrives rather than the signal
 * a reader waits on. Without a window the site TTL applies, which is what
 * every heartbeat-backed writer wants.
 *
 * Measured from the row's own timestamp, so a backdated row expires on the
 * writer's clock rather than this one.
 *
 * @access private
 *
 * @since 0.7.0
 *
 * @param string   $date_gmt   The row's timestamp, `Y-m-d H:i:s` in UTC.
 * @param int|null $expires_in Optional. Seconds the row stays present. Default the site TTL.
 * @return string The expiry, `Y-m-d H:i:s` in UTC.
 */
function wp_presence_expiry_for( $date_gmt, $expires_in = null ) {
	if ( null === $expires_in ) {
		$expires_in = wp_presence_get_timeout();
	}

	$expires_in = min( max( 1, (int) $expires_in ), wp_presence_max_expires_in() );

	return gmdate( 'Y-m-d H:i:s', strtotime( $date_gmt . ' UTC' ) + $expires_in );
}

/**
 * The longest window any row may carry, in seconds.
 *
 * The ceiling on the same hole the `$date_gmt` clamp closes from the other
 * end: without it a caller could keep a row indefinitely, which is what the
 * TTL exists to prevent. It is also the most a row can outlive its last
 * activity, so the privacy policy text and the personal data export report
 * this figure rather than the TTL.
 *
 * @access private
 *
 * @since 0.7.0
 *
 * @return int Seconds, at least 1.
 */
function wp_presence_max_expires_in() {
	/**
	 * Filters the longest window a writer may ask for through `$expires_in`.
	 *
	 * @since 0.7.0
	 *
	 * @param int $max Seconds. Default HOUR_IN_SECONDS.
	 */
	return max( 1, (int) apply_filters( 'wp_presence_max_expires_in', HOUR_IN_SECONDS ) );
}

/**
 * Upserts a presence row.
 *
 * Given a refresh cutoff, an unchanged row newer than it keeps its date_gmt, so
 * no row is affected and the admin-room signal stays quiet.
 *
 * @access private
 *
 * @since 0.6.0
 * @since 0.7.0 Added the `$refresh_cutoff` parameter.
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string      $room           The room identifier.
 * @param string      $client_id      The client identifier.
 * @param int         $user_id        The user ID.
 * @param string      $data_json      The presence state, JSON encoded.
 * @param string      $date_gmt       The GMT timestamp to stamp the row with.
 * @param string|null $expires_gmt    Optional. When the row stops counting as present.
 *                                    Default the site TTL from `$date_gmt`.
 * @param string      $refresh_cutoff Optional. As returned by wp_presence_refresh_cutoff().
 *                                    Default empty, which always stamps $date_gmt.
 * @return bool True on success, false on failure.
 */
function wp_presence_write_row( $room, $client_id, $user_id, $data_json, $date_gmt, $expires_gmt = null, $refresh_cutoff = '' ) {
	global $wpdb;

	// Repeated from wp_set_presence() for the callers that come here directly.
	if ( ! wp_presence_recording_enabled() || ! wp_presence_has_table() ) {
		return false;
	}

	if ( null === $expires_gmt ) {
		$expires_gmt = wp_presence_expiry_for( $date_gmt );
	}

	$date_clause = 'date_gmt = VALUES(date_gmt), expires_gmt = VALUES(expires_gmt)';
	$args        = array( $room, $client_id, $user_id, $data_json, $date_gmt, $expires_gmt );

	if ( '' !== $refresh_cutoff ) {
		// MySQL assigns left to right, so expires_gmt is tested first, while
		// date_gmt and data still hold the values the test is asking about.
		$taken       = 'data <> VALUES(data) OR date_gmt < %s';
		$date_clause = "expires_gmt = IF( {$taken}, VALUES(expires_gmt), expires_gmt ), date_gmt = IF( {$taken}, VALUES(date_gmt), date_gmt )";
		$args[]      = $refresh_cutoff;
		$args[]      = $refresh_cutoff;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$result = $wpdb->query(
		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"INSERT INTO {$wpdb->presence} (room, client_id, user_id, data, date_gmt, expires_gmt) VALUES (%s, %s, %d, %s, %s, %s) ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), {$date_clause}, data = VALUES(data)",
			...$args
		)
	);

	if ( $result > 0 && wp_presence_admin_room() === $room ) {
		wp_presence_admin_room_changed();
	}

	return false !== $result;
}

/**
 * Removes a client from a room.
 *
 * @param string $room      The room identifier.
 * @param string $client_id The client identifier.
 * @return bool True on success, false on failure.
 */
function wp_remove_presence( $room, $client_id ) {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return false;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$result = $wpdb->delete(
		$wpdb->presence,
		array(
			'room'      => $room,
			'client_id' => $client_id,
		),
		array( '%s', '%s' )
	);

	if ( $result > 0 && wp_presence_admin_room() === $room ) {
		wp_presence_admin_room_changed();
	}

	return false !== $result;
}

/**
 * Upserts a client's presence state and returns the room as it stands afterwards.
 *
 * For a caller that reads the room back after every write, such as an
 * awareness backend. The read is scoped to `$client_prefix`, so it returns the
 * caller's own rows without the ones other clients keep in the same room.
 *
 * @since 0.8.0
 *
 * @param string $room          The room identifier.
 * @param string $client_id     The client identifier.
 * @param array  $state         The presence state data.
 * @param int    $user_id       Optional. The user ID. Default 0.
 * @param int    $timeout       Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @param string $client_prefix Optional. Only return clients whose client_id starts with this.
 *                              Default empty.
 * @return array Array of presence entry objects, as returned by wp_get_presence().
 */
function wp_presence_exchange( $room, $client_id, $state, $user_id = 0, $timeout = null, $client_prefix = '' ) {
	wp_set_presence( $room, $client_id, $state, $user_id );

	return wp_get_presence( $room, $timeout, $client_prefix );
}

/**
 * Removes a client from a room and returns the room as it stands afterwards.
 *
 * The removal counterpart to wp_presence_exchange().
 *
 * @since 0.8.0
 *
 * @param string $room          The room identifier.
 * @param string $client_id     The client identifier.
 * @param int    $timeout       Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @param string $client_prefix Optional. Only return clients whose client_id starts with this.
 *                              Default empty.
 * @return array Array of presence entry objects, as returned by wp_get_presence().
 */
function wp_presence_leave( $room, $client_id, $timeout = null, $client_prefix = '' ) {
	wp_remove_presence( $room, $client_id );

	return wp_get_presence( $room, $timeout, $client_prefix );
}

/**
 * Removes all presence entries for a given user across all rooms.
 *
 * @param int $user_id The user ID.
 * @return bool True on success, false on failure.
 */
function wp_remove_user_presence( $user_id ) {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return false;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$result = $wpdb->delete(
		$wpdb->presence,
		array( 'user_id' => $user_id ),
		array( '%d' )
	);

	// Deletes across every room, so the admin room is always among them.
	if ( $result > 0 ) {
		wp_presence_admin_room_changed();
	}

	return false !== $result;
}

/**
 * Signals that a write may have changed who's online on this site.
 *
 * Called from every path that writes the admin room: the heartbeat tick, the
 * server-side write on page render, login, logout, and the REST set/delete
 * behind the pagehide handler.
 *
 * @access private
 */
function wp_presence_admin_room_changed() {
	/**
	 * Fires after a write that may have changed who's online on this site.
	 *
	 * Fires when an admin-room write changes at least one row.
	 *
	 * @since 0.2.0
	 */
	do_action( 'wp_presence_admin_room_changed' );
}

/**
 * Parses a room identifier.
 *
 * Room format: `postType/{post_type}:{post_id}`
 *
 * @access private
 * @param string $room The room identifier.
 * @return array|false An array containing 'post_type' and 'post_id' on success, false otherwise.
 */
function wp_presence_parse_room( $room ) {
	if ( preg_match( '#^postType/([^:]+):(\d+)$#', $room, $matches ) ) {
		return array(
			'post_type' => $matches[1],
			'post_id'   => (int) $matches[2],
		);
	}

	return false;
}

/**
 * Checks if a user can access a presence room.
 *
 * @param string $room    The room identifier.
 * @param int    $user_id Optional. The user ID. Default 0 (current user).
 * @return bool True if the user can access the room, false otherwise.
 */
function wp_can_access_presence_room( $room, $user_id = 0 ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}

	if ( ! $user_id ) {
		return false;
	}

	$parsed = wp_presence_parse_room( $room );
	if ( $parsed ) {
		return user_can( $user_id, 'edit_post', $parsed['post_id'] );
	}

	return user_can( $user_id, 'edit_posts' );
}

/**
 * Returns the presence room identifier for a given post.
 *
 * Room format: `postType/{post_type}:{post_id}`
 *
 * @param int|WP_Post $post The post ID or post object.
 * @return string|false The room identifier, or false if the post doesn't exist
 *                      or its post type does not support presence.
 */
function wp_presence_post_room( $post ) {
	$post = get_post( $post );

	if ( ! $post ) {
		return false;
	}

	if ( ! post_type_supports( $post->post_type, 'presence' ) ) {
		return false;
	}

	return 'postType/' . $post->post_type . ':' . $post->ID;
}

/**
 * Returns the presence room identifier for the admin "who's online" list.
 *
 * @return string The room identifier.
 */
function wp_presence_admin_room() {
	return 'admin/online';
}

/*
 *
 * The following functions are used by the plugin's widgets, CLI, REST
 * controller, and cron jobs. They are not part of the public API contract
 * and may change or be removed without notice. Do not depend on them.
 */

/**
 * Resolves a timeout, falling back to the site's filtered TTL.
 *
 * A caller that named a window gets that window on every site. Only the
 * fallback is filtered, so a site cannot widen someone else's liveness check.
 *
 * @access private
 * @param int|null $timeout Timeout in seconds, or null for the site's TTL.
 * @return int The timeout in seconds.
 */
function wp_presence_get_timeout( $timeout = null ) {
	if ( null !== $timeout ) {
		return max( 0, (int) $timeout );
	}

	/**
	 * Filters the presence TTL (time-to-live) used when a caller names no window.
	 *
	 * @param int $timeout The timeout in seconds. Default WP_PRESENCE_DEFAULT_TTL (150).
	 */
	return max( 0, (int) apply_filters( 'wp_presence_default_ttl', WP_PRESENCE_DEFAULT_TTL ) );
}

/**
 * Gets all presence entries for rooms matching a prefix.
 *
 * @access private
 * @param string $prefix  The room prefix to match (e.g., 'postType/').
 * @param int    $timeout Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @return array Array of presence entry objects.
 */
function wp_get_presence_by_room_prefix( $prefix, $timeout = null ) {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return array();
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );
	$stale  = wp_presence_read_floor( $timeout );

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$results = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT room, client_id, user_id, data, date_gmt FROM {$wpdb->presence} WHERE room LIKE %s AND expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s ORDER BY date_gmt DESC",
			$wpdb->esc_like( $prefix ) . '%',
			$cutoff,
			$stale,
			wp_presence_reserved_client_id_pattern()
		)
	);

	if ( ! $results ) {
		return array();
	}

	foreach ( $results as $row ) {
		$decoded   = json_decode( $row->data, true );
		$row->data = is_array( $decoded ) ? $decoded : array();
	}

	return $results;
}

/**
 * Returns a site-wide presence summary grouped by room prefix.
 *
 * @access private
 * @param int $timeout Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @return array {
 *     @type int   $total_entries Total presence entries.
 *     @type int   $total_users   Distinct user count.
 *     @type array $by_prefix     Associative array keyed by prefix, each with 'entries' and 'users'.
 * }
 */
function wp_get_presence_summary( $timeout = null ) {
	global $wpdb;

	$summary = array(
		'total_entries' => 0,
		'total_users'   => 0,
		'by_prefix'     => array(),
	);

	if ( ! wp_presence_has_table() ) {
		return $summary;
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );
	$stale  = wp_presence_read_floor( $timeout );

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$room_rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT room, COUNT(*) AS entries FROM {$wpdb->presence} WHERE expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s GROUP BY room",
			$cutoff,
			$stale,
			wp_presence_reserved_client_id_pattern()
		)
	);

	if ( ! $room_rows ) {
		return $summary;
	}

	// Grouped by prefix in PHP to avoid MySQL-specific SUBSTRING_INDEX().
	// Distinct user counts aren't additive across rooms, so those come from
	// a per-prefix query below rather than being summed here.
	$rooms_by_prefix = array();

	foreach ( $room_rows as $row ) {
		$prefix  = explode( '/', $row->room, 2 )[0];
		$entries = (int) $row->entries;

		if ( ! isset( $summary['by_prefix'][ $prefix ] ) ) {
			$summary['by_prefix'][ $prefix ] = array(
				'entries' => 0,
				'users'   => 0,
			);
			$rooms_by_prefix[ $prefix ]      = array();
		}

		$summary['by_prefix'][ $prefix ]['entries'] += $entries;
		$summary['total_entries']                   += $entries;
		$rooms_by_prefix[ $prefix ][]                = $row->room;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$summary['total_users'] = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->presence} WHERE expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s",
			$cutoff,
			$stale,
			wp_presence_reserved_client_id_pattern()
		)
	);

	foreach ( $rooms_by_prefix as $prefix => $rooms ) {
		$placeholders = implode( ', ', array_fill( 0, count( $rooms ), '%s' ) );

		// $placeholders holds only %s tokens generated above, so the interpolation is safe.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$summary['by_prefix'][ $prefix ]['users'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->presence} WHERE expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s AND room IN ( $placeholders )", array_merge( array( $cutoff, $stale, wp_presence_reserved_client_id_pattern() ), $rooms ) ) );
	}

	return $summary;
}

/**
 * Deletes stale presence entries older than the default TTL.
 *
 * Runs on the every-minute cron event. Rather than looping without a ceiling
 * over the MySQL-only `DELETE ... LIMIT` construct, this selects a bounded
 * page of primary keys older than the cutoff and deletes them by key, for a
 * fixed number of passes per invocation. Any remaining backlog is left for the
 * next cron run, so a single request cannot run until `max_execution_time`
 * when a site returns from a cron outage with a large backlog. Deleting by
 * primary key also keeps the query portable to non-MySQL backends, such as the
 * SQLite integration Playground uses to run the demo blueprints.
 *
 * @access private
 */
function wp_delete_expired_presence_data() {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return;
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );

	/**
	 * Filters the number of expired rows deleted per pass.
	 *
	 * @param int $batch_size Rows per pass. Default 1000.
	 */
	$batch_size = (int) apply_filters( 'wp_presence_cleanup_batch_size', 1000 );

	/**
	 * Filters the maximum number of delete passes per cron invocation.
	 *
	 * The remainder is left for the next scheduled run, bounding the work a
	 * single request performs.
	 *
	 * @param int $max_passes Passes per invocation. Default 10.
	 */
	$max_passes = (int) apply_filters( 'wp_presence_cleanup_max_passes', 10 );

	if ( $batch_size < 1 || $max_passes < 1 ) {
		return;
	}

	for ( $pass = 0; $pass < $max_passes; $pass++ ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->presence} WHERE expires_gmt <= %s ORDER BY id ASC LIMIT %d",
				$cutoff,
				$batch_size
			)
		);

		if ( empty( $ids ) ) {
			break;
		}

		$ids          = array_map( 'intval', $ids );
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

		// IDs are cast to integers above and passed to prepare() as %d
		// replacements, so the interpolated placeholder list is safe.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->presence} WHERE id IN ( $placeholders )", $ids ) );

		if ( count( $ids ) < $batch_size ) {
			break;
		}
	}
}

/**
 * Checks the database directly for the presence table.
 *
 * Only for the provisioning path. Request paths use wp_presence_has_table(),
 * which reads an autoloaded option and costs nothing.
 *
 * @access private
 * @return bool Whether the table exists on the current site.
 */
function wp_presence_table_exists() {
	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->presence ) ) );

	return $found === $wpdb->presence;
}

/**
 * Takes an exclusive lock, or reports that another request already holds it.
 *
 * Mirrors WP_Upgrader::create_lock(), which core uses to keep its own upgrade
 * routines from running twice over, in WP_Core_Upgrader::upgrade() and in
 * WP_Automatic_Updater::run(). The insert is the lock: option_name is unique,
 * so exactly one concurrent caller can create the row. That also means it holds
 * on sites with no persistent object cache, where wp_cache_add() is per request
 * and would coordinate nothing.
 *
 * Written out here rather than calling WP_Upgrader::create_lock() so that
 * provisioning does not have to load the whole upgrader stack on admin_init and
 * cli_init for the sake of one static method.
 *
 * @access private
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string $lock_name       Name of the lock.
 * @param int    $release_timeout Optional. Seconds after which an unreleased
 *                                lock is treated as abandoned. Default
 *                                MINUTE_IN_SECONDS.
 * @return bool Whether the lock was taken.
 */
function wp_presence_create_lock( $lock_name, $release_timeout = null ) {
	global $wpdb;

	if ( ! $release_timeout ) {
		$release_timeout = MINUTE_IN_SECONDS;
	}

	$lock_option = $lock_name . '.lock';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$lock_result = $wpdb->query(
		$wpdb->prepare(
			"INSERT IGNORE INTO `$wpdb->options` ( `option_name`, `option_value`, `autoload` ) VALUES (%s, %s, 'off') /* LOCK */",
			$lock_option,
			time()
		)
	);

	if ( ! $lock_result ) {
		$lock_result = get_option( $lock_option );

		// No lock and no row to read means the insert failed for another reason.
		if ( ! $lock_result ) {
			return false;
		}

		// Someone else holds it and has not had long enough to be abandoned.
		if ( $lock_result > ( time() - $release_timeout ) ) {
			return false;
		}

		// A request died holding it. Clear it and take it, so one lost request
		// cannot leave the site unprovisionable.
		wp_presence_release_lock( $lock_name );

		return wp_presence_create_lock( $lock_name, $release_timeout );
	}

	// The insert above bypassed the options cache, so bring it back in line.
	update_option( $lock_option, time(), false );

	return true;
}

/**
 * Releases a lock taken by wp_presence_create_lock().
 *
 * @access private
 *
 * @see wp_presence_create_lock()
 *
 * @param string $lock_name Name of the lock.
 * @return bool Whether the lock was released.
 */
function wp_presence_release_lock( $lock_name ) {
	return delete_option( $lock_name . '.lock' );
}

/**
 * Creates or updates the presence table if needed.
 *
 * Feature plugin shim — in core, this table would be created by dbDelta()
 * during the database upgrade routine in wp-admin/includes/upgrade-schema.php.
 *
 * The version option alone is not enough to skip the work. If the table is
 * dropped while the option survives, a partial restore or a hand-run DROP,
 * every read and write fails and nothing reconciles the two.
 *
 * Ajax is excluded from that reconciliation. admin-ajax.php fires admin_init
 * too, and presence heartbeats through it every 15 seconds per open admin tab,
 * so checking there would bill every site continuously for a state almost none
 * of them will reach. The next real admin page load repairs it instead.
 *
 * @access private
 */
function wp_maybe_create_presence_table() {
	add_option( 'wp_presence_recording', '1', '', true );

	$provisioned = (int) get_option( 'wp_presence_db_version' ) === WP_PRESENCE_DB_VERSION;

	if ( $provisioned && ( wp_doing_ajax() || wp_presence_table_exists() ) ) {
		return;
	}

	// admin_init and cli_init have no confirmation step to serialize them the
	// way wp-admin/upgrade.php does for core, so two requests can arrive here at
	// once during a version bump. Whoever loses the race returns and lets the
	// winner finish; the next request repairs anything left over.
	if ( ! wp_presence_create_lock( 'wp_presence_table' ) ) {
		return;
	}

	global $wpdb;

	$charset_collate  = $wpdb->get_charset_collate();
	$max_index_length = WP_PRESENCE_MAX_KEY_LENGTH;

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta(
		"CREATE TABLE {$wpdb->presence} (
			id bigint(20) unsigned NOT NULL auto_increment,
			room varchar({$max_index_length}) NOT NULL default '',
			client_id varchar({$max_index_length}) NOT NULL default '',
			user_id bigint(20) unsigned NOT NULL default '0',
			data longtext NOT NULL,
			date_gmt datetime NOT NULL default '0000-00-00 00:00:00',
			expires_gmt datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY room_client (room, client_id),
			KEY date_gmt (date_gmt),
			KEY expires_gmt (expires_gmt),
			KEY user_id (user_id),
			KEY room_date (room(40), date_gmt),
			KEY room_expires (room(40), expires_gmt)
		) {$charset_collate};"
	);

	// Autoloaded explicitly: wp_presence_has_table() reads this on every request
	// that touches presence, so it must not cost a query.
	update_option( 'wp_presence_db_version', WP_PRESENCE_DB_VERSION, true );

	wp_presence_release_lock( 'wp_presence_table' );
}

/**
 * Returns all active rooms with their user counts and member lists.
 *
 * @access private
 *
 * @param int  $timeout        Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @param bool $hydrate_users  Optional. Whether to hydrate user data. Default true.
 * @return array Array of room objects, each with 'room', 'user_count', and optionally 'users'.
 */
function wp_get_active_rooms( $timeout = null, $hydrate_users = true ) {
	global $wpdb;

	if ( ! wp_presence_has_table() ) {
		return array();
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );
	$stale  = wp_presence_read_floor( $timeout );

	// First pass: get room names and counts only (no user IDs).
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$room_stats = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT room, COUNT(DISTINCT user_id) as user_count
			FROM {$wpdb->presence}
			WHERE expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s
			GROUP BY room",
			$cutoff,
			$stale,
			wp_presence_reserved_client_id_pattern()
		)
	);

	if ( ! $room_stats ) {
		return array();
	}

	// Sort by user count descending, then room name.
	usort(
		$room_stats,
		function ( $a, $b ) {
			if ( $a->user_count === $b->user_count ) {
				return strcmp( $a->room, $b->room );
			}
			return $b->user_count <=> $a->user_count;
		}
	);

	$rooms = array();

	foreach ( $room_stats as $stat ) {
		$room_data = array(
			'room'       => $stat->room,
			'user_count' => (int) $stat->user_count,
		);

		if ( $hydrate_users ) {
			// Query user IDs only for this room.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$user_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT user_id
					FROM {$wpdb->presence}
					WHERE room = %s AND expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s",
					$stat->room,
					$cutoff,
					$stale,
					wp_presence_reserved_client_id_pattern()
				)
			);

			$users = array();
			foreach ( $user_ids as $uid ) {
				$user = get_userdata( (int) $uid );

				if ( ! $user ) {
					continue;
				}

				$users[] = array(
					'user_id'      => (int) $uid,
					'display_name' => $user->display_name,
					'avatar_url'   => get_avatar_url( $uid, array( 'size' => 48 ) ),
				);
			}

			$room_data['users']      = $users;
			$room_data['user_count'] = count( $users );
		}

		$rooms[] = $room_data;
	}

	return $rooms;
}

/**
 * Hydrates user data for a list of rooms.
 *
 * @access private
 *
 * @param array $rooms   Array of room data (each with a 'room' key).
 * @param int   $timeout Optional. Timeout in seconds. Default null, the site's filtered TTL.
 * @return array Rooms with hydrated user arrays.
 */
function wp_presence_hydrate_room_users( $rooms, $timeout = null ) {
	global $wpdb;

	if ( empty( $rooms ) ) {
		return $rooms;
	}

	$cutoff = gmdate( 'Y-m-d H:i:s' );
	$stale  = wp_presence_read_floor( $timeout );

	// Get user IDs for all rooms in one query.
	$room_names   = wp_list_pluck( $rooms, 'room' );
	$placeholders = implode( ', ', array_fill( 0, count( $room_names ), '%s' ) );

	// Dynamic IN clause: $placeholders is "%s, %s, ..." built from count, not user data.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$rows = $wpdb->get_results(
		$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			"SELECT room, user_id
			FROM {$wpdb->presence}
			WHERE room IN ($placeholders) AND expires_gmt > %s AND date_gmt > %s AND client_id NOT LIKE %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			array_merge( $room_names, array( $cutoff, $stale, wp_presence_reserved_client_id_pattern() ) )
		)
	);

	// Group user IDs by room.
	$room_user_ids = array();
	$all_user_ids  = array();
	foreach ( $rows as $row ) {
		$uid                           = (int) $row->user_id;
		$room_user_ids[ $row->room ][] = $uid;
		$all_user_ids[ $uid ]          = true;
	}

	// Prime user cache.
	if ( ! empty( $all_user_ids ) ) {
		cache_users( array_keys( $all_user_ids ) );
	}

	// Hydrate each room.
	foreach ( $rooms as &$room ) {
		$users = array();

		if ( isset( $room_user_ids[ $room['room'] ] ) ) {
			foreach ( array_unique( $room_user_ids[ $room['room'] ] ) as $uid ) {
				$user = get_userdata( $uid );

				if ( ! $user ) {
					continue;
				}

				$users[] = array(
					'user_id'      => $uid,
					'display_name' => $user->display_name,
					'avatar_url'   => get_avatar_url( $uid, array( 'size' => 48 ) ),
				);
			}
		}

		$room['users']      = $users;
		$room['user_count'] = count( $users );
	}

	return $rooms;
}

/**
 * Enqueues the shared avatar-stack stylesheet.
 *
 * @access private
 */
function wp_presence_enqueue_avatar_stack_style() {
	wp_enqueue_style(
		'wp-presence-avatar-stack',
		WP_PRESENCE_PLUGIN_URL . 'assets/css/avatar-stack.css',
		array(),
		WP_PRESENCE_VERSION
	);
}

/**
 * Enqueues the shared avatar-stack script.
 *
 * Only the two widgets that repaint over Heartbeat need it; a stack rendered
 * once per page load is served by the PHP renderer alone.
 *
 * @access private
 */
function wp_presence_enqueue_avatar_stack_script() {
	wp_enqueue_script(
		'wp-presence-avatar-stack',
		WP_PRESENCE_PLUGIN_URL . 'assets/js/avatar-stack.js',
		array(),
		WP_PRESENCE_VERSION,
		true
	);
}

/**
 * Renders a small avatar stack for a list of users.
 *
 * Shared across every surface that shows an overlapping avatar stack (the
 * dashboard widget's overflow indicator, the network Sites list column, the
 * network dashboard widget) so they all render the stack identically, and
 * mirrored by wpPresenceBuildAvatarStack() in assets/js/avatar-stack.js for
 * the widgets that repaint over Heartbeat.
 *
 * assets/css/avatar-stack.css sizes the avatars; the attributes below only
 * reserve the space until it loads.
 *
 * @access private
 * @param array $users Users, each with 'avatar_url' and 'display_name'.
 * @param int   $max   Optional. Maximum avatars to show. Default 4.
 * @return string HTML markup.
 */
function wp_presence_render_avatar_stack( $users, $max = 4 ) {
	$shown = array();

	// get_avatar_url() returns false with the Show Avatars setting off.
	foreach ( array_slice( $users, 0, $max ) as $user ) {
		if ( ! empty( $user['avatar_url'] ) ) {
			$shown[] = $user;
		}
	}

	$html = '<span class="presence-avatar-stack">';

	foreach ( $shown as $index => $user ) {
		$z     = count( $shown ) - $index;
		$html .= '<img src="' . esc_url( $user['avatar_url'] ) . '" width="20" height="20" style="z-index:' . (int) $z . '" alt="' . esc_attr( $user['display_name'] ) . '" />';
	}

	$html .= '</span>';

	return $html;
}
