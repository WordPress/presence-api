=== Presence API ===
Contributors: joefusco, intenzi, ashishjii, iamchitti, iqbal1hossain, wp24horas, aldorza, bejignesh, stfulldev, obenland, moriikuri, ishitaj34, theaminuldev, muneebashraf, mindctrl, zahidui, mitgiselle, jaredrethman, jooahmed, noruzzaman, huzaifaalmesbah, rejaulalomkhan, bosskhj, hmbashar, devmuhib, khushalsains
Tags: presence, awareness, heartbeat, real-time
Requires at least: 7.0
Tested up to: 7.1
Stable tag: 0.20.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: presence-api

System-wide presence and awareness for WordPress.

== Description ==

Presence API gives WordPress a system-wide awareness layer. It tracks which users are logged in, which admin screen they are on, and which posts they are editing.

Data flows through the Heartbeat API and is stored in a dedicated `wp_presence` table with a 150-second TTL. No writes to `wp_postmeta` means no post-cache invalidation on every heartbeat.

On a multisite network, Network Admin gets its own view of the same data: a Who's Online dashboard widget listing the busiest sites and who is on each, an Online column in the Sites list, and an Online view, filter, and column in the Users list. These require the `manage_network` capability.


= Features =

* Admin bar indicator showing who's online and who's on this page
* Active Posts dashboard widget grouped by post
* Editors column in the post list
* A notice on synced patterns in the block editor while someone else is editing them
* Online filter in the Users list
* A notice when someone else saves the screen you have open
* Post locks kept in the presence table instead of post meta, so holding a lock no longer makes cached post queries stale
* A switch for each feature on Settings > Presence API
* AI agents labelled in the admin bar, the Active Posts widget, and the Editors column, once a plugin such as Agent Users marks them

= For Developers =

PHP functions, REST endpoints, WP-CLI commands, filters, and room conventions are documented in the [GitHub repository](https://github.com/WordPress/presence-api).

= Background =

A feature plugin sponsored by the WordPress Core team, exploring what system-wide presence could look like for a future WordPress release. Follow development on [make.wordpress.org/core](https://make.wordpress.org/core/) with the tag `#presence-api`.

== Installation ==

1. In your WordPress admin, go to **Plugins → Add New Plugin** and search for "Presence API", then click **Install Now**.
2. Activate through the **Plugins** menu.

Or install manually:

1. Download the zip and upload the `presence-api` folder to `/wp-content/plugins/`.
2. Activate through the **Plugins** menu.

== Frequently Asked Questions ==

= Does it work on multisite? =

Yes. Network-activate it and Network Admin gains a Who's Online dashboard widget listing the busiest sites and who is on each, an Online column in the Sites list, and an Online view, filter, and column in the Users list. Every site keeps its own widgets and lists, counting only the people on that site.

= Who can see network-wide presence? =

Anyone with the `manage_network` capability, which on a default network means super admins. The `wp_presence_network_capability` filter changes what is required.

= Can a site stop recording presence? =

Yes. Clear the **Presence** checkbox on Settings > General, or run `wp presence recording set off`. Every screen empties as the rows already stored expire. On multisite, Network Admin > Settings has the same checkbox for every site at once; whichever switch is off decides.

For code, the `wp_presence_recording_enabled` and `wp_presence_network_recording_enabled` filters take the checkboxes as their defaults, so a filter always has the last word.

== Screenshots ==

1. The dashboard with 101 people online, the admin bar's presence menu open, and Active Posts listing who is editing each post and page.
2. The Posts list, with an Editors column showing who has each post open.
3. The Users list filtered to the people online right now.
4. The notice someone sees when another person saves the settings screen they have open.
5. Settings > Presence API, where a site switches features off.
6. Network Admin's Who's Online widget, listing the busiest sites and how many people are on each.

== Changelog ==

Only the most recent releases are listed here. For the full history, see https://github.com/WordPress/presence-api/blob/main/CHANGELOG.md

= 0.20.2 =
* Draw the admin bar icons as WordPress 7.2 SVG icons ([#940](https://github.com/WordPress/presence-api/issues/940)).

= 0.20.1 =
* Keep presence during in-site navigation ([#931](https://github.com/WordPress/presence-api/issues/931)).
* Keep the stale-screen notice's time current ([#930](https://github.com/WordPress/presence-api/issues/930)).
* Let follower tabs ask for live surfaces that have a request() ([#932](https://github.com/WordPress/presence-api/issues/932)).

= 0.20.0 =
* Add wp_presence_admin_state() so a relay can write the rows Heartbeat writes ([#924](https://github.com/WordPress/presence-api/issues/924)).
* Fire `wp_presence_room_changed` when an edited post's title or status changes ([#915](https://github.com/WordPress/presence-api/issues/915)).
* Keep the admin bar's presence menu current while it is open ([#914](https://github.com/WordPress/presence-api/issues/914)).

= 0.19.0 =
* Add a presence-api.keepalive filter so a push transport can hold a tab's rows ([#904](https://github.com/WordPress/presence-api/issues/904)).
* Add a presence-api.roomChanged action that refreshes presence now ([#903](https://github.com/WordPress/presence-api/issues/903)).

= 0.18.4 =
* Clear the cleanup cron event on plugin uninstall ([#872](https://github.com/WordPress/presence-api/issues/872)).
* Preserve post locks on logout from another session ([#893](https://github.com/WordPress/presence-api/issues/893)).
* Exclude reserved rows from personal data export ([#896](https://github.com/WordPress/presence-api/issues/896)).
* Store no session hash on a post room's one editor row per person ([#884](https://github.com/WordPress/presence-api/issues/884)).
* Write wp presence set as WP-CLI's --user, and three smaller corrections ([#887](https://github.com/WordPress/presence-api/issues/887)).
